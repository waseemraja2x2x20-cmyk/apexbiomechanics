---
name: Apex Biomechanics
colors:
  surface: '#111319'
  surface-dim: '#111319'
  surface-bright: '#36393f'
  surface-container-lowest: '#0b0e13'
  surface-container-low: '#191c21'
  surface-container: '#1d2025'
  surface-container-high: '#272a30'
  surface-container-highest: '#32353b'
  on-surface: '#e1e2ea'
  on-surface-variant: '#e6bcbd'
  inverse-surface: '#e1e2ea'
  inverse-on-surface: '#2e3036'
  outline: '#ad8789'
  outline-variant: '#5d3f40'
  surface-tint: '#ffb3b6'
  primary: '#ffb3b6'
  on-primary: '#68001a'
  primary-container: '#ff5168'
  on-primary-container: '#5b0015'
  inverse-primary: '#be0037'
  secondary: '#bdf4ff'
  on-secondary: '#00363d'
  secondary-container: '#00e3fd'
  on-secondary-container: '#00616d'
  tertiary: '#b4c9de'
  on-tertiary: '#1e3243'
  tertiary-container: '#7f93a6'
  on-tertiary-container: '#172c3c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdada'
  primary-fixed-dim: '#ffb3b6'
  on-primary-fixed: '#40000c'
  on-primary-fixed-variant: '#920028'
  secondary-fixed: '#9cf0ff'
  secondary-fixed-dim: '#00daf3'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#004f58'
  tertiary-fixed: '#d0e5fa'
  tertiary-fixed-dim: '#b4c9de'
  on-tertiary-fixed: '#071d2d'
  on-tertiary-fixed-variant: '#35495a'
  background: '#111319'
  on-background: '#e1e2ea'
  surface-variant: '#32353b'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Sora
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Sora
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Hanken Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Hanken Grotesk
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Hanken Grotesk
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Hanken Grotesk
    fontSize: 9px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.25rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 1.5rem
  margin-desktop: 2rem
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system establishes a high-performance biomechanical training aesthetic that combines laboratory-grade kinetic telemetry with elite athletic intensity. Designed for elite athletes, kinetic specialists, physical therapists, and data-driven lifters, the interface evokes intense focus, clinical precision, and raw physiological power.

The visual style merges technical brutalism with hyper-refined glassmorphism:
- **Carbon-Clad Technical Precision:** Ultra-dark slate and carbon surfaces (`#090B0E`, `#11161B`) eliminate visual noise, letting anatomical heatmaps and muscular activation vectors dominate the viewport.
- **Biomechanical Vector Contrast:** High-frequency neon cyan and surgical crimson accents mirror physiological states—crimson representing maximum peak muscle contraction and fiber recruitment; cyan detailing agonist stabilization, balance vectors, and telemetry conduits.
- **HUD-Inspired Data Architecture:** Monospaced metric arrays, compact metric chips, and micro-grid textures anchor telemetry without cluttering the biomechanical canvas.

## Colors

The chromatic strategy relies on stark anatomical polarity over deep, low-luminance substrates:

- **Primary (`#FF2A55` - Crimson Kinetic):** Represents peak kinetic output, maximum contraction, primary active muscle groups, and critical biomechanical alerts.
- **Secondary (`#00E5FF` - Cyan Vector):** Applied to stabilization paths, joint angle indicators, secondary muscle recruitment, and live range-of-motion trajectories.
- **Tertiary (`#708497` - Slate Telemetry):** Anchors secondary telemetry readouts, structural axes, baseline grid overlays, and inactive skeletal frameworks.
- **Neutral (`#0B0E13` - Carbon Void):** The foundational substrate. Built on deep cold-charcoal tiers that absorb ambient glare and provide infinite contrast for luminescent data overlays.

### Surface System
- **Base Canvas:** `#07090C`
- **Surface Level 1 (Card Background):** `rgba(17, 22, 28, 0.72)` with border `rgba(112, 132, 151, 0.15)`
- **Surface Level 2 (Telemetry Wells & Floating Drawers):** `rgba(22, 29, 38, 0.85)` with border `rgba(112, 132, 151, 0.24)`
- **Surface Highlight:** Subtle gradient sheen using `linear-gradient(135deg, rgba(255, 42, 85, 0.08) 0%, rgba(0, 229, 255, 0.04) 100%)`

## Typography

The type system pairs **Sora**—a high-tech, wide geometric sans with distinctive architectural terminals—with **Hanken Grotesk**—an ultra-clean, clinical grotesque delivering maximum legibility in dense kinetic data views.

- **Headlines & Telemetry Callouts (Sora):** Used for load figures, primary physiological target headings, muscle group tags, and large numerical readouts. Bold weights provide an imposing, authoritative presence.
- **Body & Continuous Metric Arrays (Hanken Grotesk):** Provides frictionless readability across exercise prescriptions, form critiques, and kinetic diagnostic notes.
- **Labels & Micro Telemetry:** Set exclusively in uppercase with expanded tracking (`0.04em` to `0.08em`) to mirror technical heads-up displays and medical instrumentation.

## Layout & Spacing

The layout model utilizes an 8pt base grid system optimized for dense information density without compromising touch targets during physical exertion.

### Grid Architecture
- **Mobile (< 768px):** 4-column fluid layout, `margin: 1rem`, `gutter: 1rem`. Critical biomechanical visualizers occupy full width, with pinned telemetry chips.
- **Tablet (768px - 1024px):** 8-column layout, `margin: 1.5rem`, `gutter: 1.25rem`. Split views displaying anatomical 3D render side-by-side with real-time force velocity curves.
- **Desktop (> 1024px):** 12-column layout, `margin: 2rem`, `gutter: 1.5rem`. Max container width capped at `1440px` with fixed analytical rail architecture.

### Density Rules
- Telemetry clusters (e.g., heart rate, velocity, tension percentage) use condensed `space-xs` (4px) to `space-sm` (8px) internal gaps to form unified data clusters.
- Major anatomical card sections breathe with `space-lg` (24px) spacing, preventing interface interaction errors during motion tracking.

## Elevation & Depth

Visual hierarchy uses frosted glassmorphism anchored by sharp, semi-luminescent hairline contours rather than heavy diffuse drop-shadows.

### Layer Hierarchy
1. **Base Layer (Ground):** Solid canvas (`#07090C`) with faint dot-matrix or technical isometric coordinates (`rgba(112, 132, 151, 0.04)`).
2. **Level 1 (Telemetry & Exercise Panels):** Frosted glass (`background: rgba(17, 22, 28, 0.75)`, `backdrop-filter: blur(16px)`), bound by a 1px ghost border (`rgba(112, 132, 151, 0.16)`).
3. **Level 2 (Interactive Floating Controls & Active Badges):** Slightly lighter acrylic fill (`background: rgba(26, 34, 44, 0.85)`, `backdrop-filter: blur(24px)`), with upper-left edge refraction (`1px solid rgba(255, 255, 255, 0.12)`).
4. **Active/Kinetic Overlays:** Accent glows featuring localized colored backlights:
   - Contraction State: `box-shadow: 0 0 20px -4px rgba(255, 42, 85, 0.45)`
   - Stabilization State: `box-shadow: 0 0 20px -4px rgba(0, 229, 255, 0.35)`

## Shapes

With a roundedness level of `1`, this design system avoids round, playful organic shapes in favor of sharp, high-precision geometry reminiscent of aerospace avionics and medical imaging instruments.

- **Base Components (Cards, Panels, Inputs):** `0.25rem` (4px) radius. Crisp, clean, and exact.
- **Containers & Modal Drawers (`rounded-lg`):** `0.5rem` (8px) radius.
- **Flyout Tooltips & System Alerts (`rounded-xl`):** `0.75rem` (12px) radius.
- **Biometric Pills & Indicator Dots:** Strict exceptions exist for circular telemetry status indicators and small metric pill tags, which use `rounded-full` (`9999px`) to visually differentiate numerical status tags from interactable rectangular cards.
- **Telemetry Callout Leaders:** 45-degree chamfered stroke connectors linking 3D muscle highlights directly to UI labels.

## Components

### Buttons
- **Primary Kinetic Action:** Solid Crimson fill (`#FF2A55`), white text (`#FFFFFF`, Sora SemiBold), 4px border radius. Hover introduces a high-intensity red glow (`box-shadow: 0 0 24px rgba(255, 42, 85, 0.5)`). Active state applies a subtle scale compression (`0.98`).
- **Secondary Telemetry Action:** Transparent background with a 1px border (`#00E5FF`), text in `#00E5FF`. Hover introduces cyan ambient surface bloom (`rgba(0, 229, 255, 0.12)`).
- **Ghost/Tertiary:** `rgba(112, 132, 151, 0.12)` background, `rgba(255, 255, 255, 0.7)` text. Minimalist, quiet framing.

### Biometric Data Badges & Chips
- **Anatomical Target Chips:** Compact capsule containers (`height: 24px`) with a solid 6px indicator pulse (Crimson for Agonist, Cyan for Synergist/Stabilizer). Background is dark tinted glass (`rgba(11, 14, 19, 0.8)`), text set in `label-sm` Sora.
- **Telemetry Readout Chip:** Tabular layout with micro-caps labels above high-contrast numerical metrics (`184 BPM`, `420 N`, `62° ROM`).

### Cards & Exercise Telemetry Panels
- **Anatomical Breakdown Card:** Framed in 1px `rgba(112, 132, 151, 0.18)` over a dark frosted substrate. Contains an integrated header with muscle tier indicators, secondary load vectors, and a live rep-by-rep bar graph.
- **HUD Glassmorphism Card:** Dual-layer border featuring a top-edge white specular highlight (`rgba(255, 255, 255, 0.08)`) and deep slate bottom edge.

### Input Fields
- **Biometric Value Inputs:** Deep slate backgrounds (`#11161B`) with inset borders (`rgba(112, 132, 151, 0.2)`). Focus triggers a crisp 1px Cyan border (`#00E5FF`) and instant numeric font rendering in Sora.
- **Telemetry Sliders:** Sleek 2px track with neon active fill (Crimson or Cyan) and a rectangular, beveled scrubber thumb (`width: 8px`, `height: 16px`, `border-radius: 2px`).

### Lists & Data Tables
- **Exercise Protocol Rows:** Alternating hairline dividers (`rgba(112, 132, 151, 0.08)`). Left-aligned exercise name, centered targeted muscle graphic icon, and right-aligned set/rep telemetry with mono-spaced numeric clarity.

### Selection Controls (Checkboxes & Radios)
- **Checkboxes:** 16x16px square boxes with 2px radius. Inactive: hairline border `rgba(112, 132, 151, 0.4)`. Checked: `#FF2A55` fill with a sharp, high-contrast check vector.
- **Segmented Mode Selectors:** Monolithic slate bar with a sliding high-contrast highlight pill, switching seamlessly between "Real-Time Telemetry", "Fatigue Heatmap", and "Kinetic Vectors".